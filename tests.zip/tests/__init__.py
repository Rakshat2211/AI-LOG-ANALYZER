"""
Tests Package Initialization
"""